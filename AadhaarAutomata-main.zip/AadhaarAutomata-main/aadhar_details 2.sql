/*
-- Query: SELECT * FROM digilocker.aadhar_details
LIMIT 0, 1000

-- Date: 2022-08-18 13:26
*/
INSERT INTO `` (`id`,`aadhar_number`,`name`,`date_of_birth`,`gender`,`address`,`contact_number`,`virtual_id`) VALUES (3,'2076 2689 5850','Mohd Aftab','2002-04-18','male ','krishna nagar ','9868486602','9156 3164 5674 1234');
INSERT INTO `` (`id`,`aadhar_number`,`name`,`date_of_birth`,`gender`,`address`,`contact_number`,`virtual_id`) VALUES (2,'3581 5645 2592','Yashika Goyal','2003-05-21','female ','krishna nagar ','8750151934','9190 9625 9239 1378');
INSERT INTO `` (`id`,`aadhar_number`,`name`,`date_of_birth`,`gender`,`address`,`contact_number`,`virtual_id`) VALUES (1,'8055 3608 7323','Radhika Sharma','2002-11-04','female','krishna nagar','8368765745','9159 3135 4330 2803');
