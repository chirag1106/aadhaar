/*
-- Query: SELECT * FROM digilocker.users
LIMIT 0, 1000

-- Date: 2022-08-18 13:40
*/
INSERT INTO `` (`id`,`first_name`,`last_name`,`contact_number`,`email_address`,`aadhar_number`) VALUES (3,'Mohd','Aftab','9868486602','mohd.aftab@gmail.com','2076 2689 5850');
INSERT INTO `` (`id`,`first_name`,`last_name`,`contact_number`,`email_address`,`aadhar_number`) VALUES (2,'Yashika ','Goyal','8750151934','goyalyashika2105@gmail.com','3581 5645 2592');
INSERT INTO `` (`id`,`first_name`,`last_name`,`contact_number`,`email_address`,`aadhar_number`) VALUES (1,'Radhika','Sharma','8368765745','radhikavasheshta@gmail.com','8055 3608 7323');
